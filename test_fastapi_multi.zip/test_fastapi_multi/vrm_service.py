"""VRM Service - sets up its own tracer"""
import asyncio
from judgeval.v1 import Judgeval
from judgeval.v1.integrations.claude_agent_sdk import setup_claude_agent_sdk
from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions

# VRM service tracer setup
client = Judgeval()
vrm_tracer = client.tracer.create(project_name="VRM-Project", isolated=True)
setup_claude_agent_sdk(vrm_tracer)
print(f"[VRM Service] Tracer setup for project: '{vrm_tracer.project_name}'")

options = ClaudeAgentOptions(model="claude-sonnet-4-20250514")

async def vrm_agent_call(prompt: str) -> str:
    """Make a Claude Agent call for VRM service"""
    async with ClaudeSDKClient(options=options) as sdk_client:
        await sdk_client.query(prompt)
        
        response_text = []
        async for message in sdk_client.receive_response():
            if hasattr(message, "content"):
                for block in message.content:
                    if hasattr(block, "text"):
                        response_text.append(block.text)
        
        return "".join(response_text)

