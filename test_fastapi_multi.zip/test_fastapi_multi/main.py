"""
FastAPI app that imports both VRM and Copilot services.
Watch the import order - whoever imports LAST wins the auto-tracer.
"""
import dotenv
dotenv.load_dotenv()

from fastapi import FastAPI

print("=" * 70)
print("FASTAPI MULTI-SERVICE TEST")
print("=" * 70)
print("\nImporting services (watch the tracer setup order)...\n")

# Import order matters! The LAST import wins the auto-tracer
from vrm_service import vrm_agent_call
from copilot_service import copilot_agent_call

print("\n" + "=" * 70)
print("RESULT: Copilot was imported LAST, so ALL Claude Agent SDK calls")
print("will trace to 'Copilot-Project' regardless of which service calls it!")
print("=" * 70 + "\n")

app = FastAPI(title="Multi-Service Test")

@app.get("/vrm")
async def vrm_endpoint():
    """VRM endpoint - but traces go to Copilot-Project!"""
    result = await vrm_agent_call("Say 'Hello from VRM' in one sentence")
    return {"service": "VRM", "response": result, "traces_go_to": "Copilot-Project (BUG!)"}

@app.get("/copilot")
async def copilot_endpoint():
    """Copilot endpoint - traces go to Copilot-Project (correct)"""
    result = await copilot_agent_call("Say 'Hello from Copilot' in one sentence")
    return {"service": "Copilot", "response": result, "traces_go_to": "Copilot-Project"}

@app.get("/test-both")
async def test_both():
    """Test both services to show the issue"""
    vrm_result = await vrm_agent_call("Just say 'VRM here'")
    copilot_result = await copilot_agent_call("Just say 'Copilot here'")
    
    return {
        "vrm": {"response": vrm_result, "traces_go_to": "Copilot-Project (WRONG!)"},
        "copilot": {"response": copilot_result, "traces_go_to": "Copilot-Project"},
        "explanation": "Both traces go to Copilot-Project because it was imported last"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

