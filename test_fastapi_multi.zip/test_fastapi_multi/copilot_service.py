"""Copilot Service - sets up its own tracer"""
import asyncio
from judgeval.v1 import Judgeval
from judgeval.v1.integrations.claude_agent_sdk import setup_claude_agent_sdk
from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions

# Copilot service tracer setup
client = Judgeval()
copilot_tracer = client.tracer.create(project_name="Copilot-Project", isolated=True)
setup_claude_agent_sdk(copilot_tracer)
print(f"[Copilot Service] Tracer setup for project: '{copilot_tracer.project_name}'")

options = ClaudeAgentOptions(model="claude-sonnet-4-20250514")

async def copilot_agent_call(prompt: str) -> str:
    """Make a Claude Agent call for Copilot service"""
    async with ClaudeSDKClient(options=options) as sdk_client:
        await sdk_client.query(prompt)
        
        response_text = []
        async for message in sdk_client.receive_response():
            if hasattr(message, "content"):
                for block in message.content:
                    if hasattr(block, "text"):
                        response_text.append(block.text)
        
        return "".join(response_text)

